
package employ;

public class Main {
    public static void main(String[] args) {
        Employ e1=new Employ();
	e1.name="Prakhar";
	e1.i=21;
	e1.display();

	Employ e2=new Employ();
 	e2.name="Prabhat";
	e2.i=16;
	e2.display();
    }
    
}
