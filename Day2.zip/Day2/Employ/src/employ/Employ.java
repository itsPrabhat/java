
package employ;

public class Employ {

    public String name;
    public int i;

    public void display(){
        System.out.println("Name is "+name);
        System.out.println("Age is "+i);
    }
    
}
