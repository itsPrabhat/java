package tax;
import java.util.Scanner;
public class Tax {
    
    public static void main(String[] args) {
    
        String name;
        int bm,by,bd,Msalary,Asalary,age;
        float tax;
        
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter employee name: ");
        name=sc.next();
        System.out.println("Enter birth date: ");
        bd=sc.nextInt();
        System.out.println("Enter birth month: ");
        bm=sc.nextInt();
        System.out.println("Enter birth year: ");
        by=sc.nextInt();
        System.out.println("Enter Monthly salary: ");
        Msalary=sc.nextInt();
        Asalary=12*Msalary;
        
        if(Asalary>500000){
        tax=Asalary/5;
        }
        else if(Asalary>400000&&Asalary<=500000){
        tax=Asalary*3/20;
        }
        else if(Asalary>300000&&Asalary<=400000){
        tax=Asalary/10;
        }
        else{
        tax=Asalary/20;
        }
        
        age=2020-by;
            
        System.out.println(name+" your age is "+age+" your annual salary is "+Asalary+" and "+tax+" you have to pay as tax");
    }
    
}
