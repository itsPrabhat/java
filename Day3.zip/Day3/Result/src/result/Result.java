/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package result;
import java.util.Scanner;
public class Result {


    public static void main(String[] args) {

                int math,eng,phy,che,bio;
                float per;
                String ch;
                Scanner n=new Scanner(System.in);
                System.out.println("Enter Math's marks ");
                math=n.nextInt();
                System.out.println("Enter English's marks ");
                eng=n.nextInt();
                System.out.println("Enter Physics's marks ");
                phy=n.nextInt();
                System.out.println("Enter Chemistry's marks ");
                che=n.nextInt();
                System.out.println("Enter Bio's marks ");
                bio=n.nextInt();

                per=math+eng+phy+che+bio;
                per=per/5;

                
                if(per>30&&per<50)
                    ch = "c";
                else if(per>=50&&per<70)
                    ch = "B";
                else if(per>=70&&per<90)
                    ch = "A";
                else if(per>=90&&per<=100)
                    ch = "A+";
                else
                    ch = "D";
                
                System.out.println("Percentage: "+per+"% and grade: "+ch);
    }
}
