package quiz;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        
        String name;
        int score=0;
        int[] ans;
        ans = new int[5];
        
        Scanner sc=new Scanner(System.in);
        
        String[] ques={"Smallest prime number is _____","Square root of 16 is _____",
            "No. of planets in solar system is _____","Biggest planet in solar system is _____",
            "Are you good boy?"};
        String[] opt1={"1","3","9","Saturn","No"};
        String[] opt2={"2","256","7","Marse","Yes"};
        String[] opt3={"3","4","8","Earth","May be"};
        String[] opt4={"0","2","10","Jupitar","don't know"};
        int[] crct={2,3,3,4,1};
 
        System.out.println("Enter your name player");
        name=sc.nextLine();
        
        for(int i=0;i<5;i++){
            
            System.out.println(ques[i]);
            System.out.println("1. "+opt1[i]);
            System.out.println("2. "+opt2[i]);
            System.out.println("3. "+opt3[i]);
            System.out.println("4. "+opt4[i]);
            System.out.println("Enter your choice");
            ans[i]=sc.nextInt();
            
            if(ans[i]==crct[i])
                score+=5;
            else
                score-=2;
        }
        
        System.out.println(name+" your score is "+score);
    }
    
}
