package question2;

public class Main {

    public static void main(String[] args) {
       
        
        Doctors dc=new Doctors();
        Engineers en=new Engineers();
        Pilots pt=new Pilots();
        
    }
    
}
