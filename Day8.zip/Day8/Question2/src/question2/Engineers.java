package question2;

public class Engineers {
    
    Engineers(){
    
        System.out.println("Operations of Engineers are: ");
        System.out.println(" ");
        System.out.println("The engineers design, invent, fix, improve, research,");
        System.out.println("travel, present, inspect, draw, write, calculate—but most of all,");
        System.out.println("they work with really interesting people on great projects ");
        System.out.println("that are changing the world for the better.");
        System.out.println(" ");
        System.out.println("--------------------------------------------------------------------------");
    
    }
    
}
