package question2;

public class Pilots {
    
    Pilots(){
    
        System.out.println("Operations of Pilots are: ");
        System.out.println(" ");
        System.out.println("Their primary responsibility is to operate the aircraft, but their day consists of many");
        System.out.println("hours performing other tasks. Pilots check the weather and confirm flight plans before");
        System.out.println("departing. They also perform pre-flight inspections and check flight logs prior to");
        System.out.println("departure.");
        System.out.println(" ");
        System.out.println("--------------------------------------------------------------------------");
    
    
    }
       
}
