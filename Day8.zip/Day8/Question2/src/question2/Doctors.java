package question2;

public class Doctors {
    
    Doctors(){
        
        System.out.println("Operations of Doctors are: ");
        System.out.println(" ");
        System.out.println("Doctors, also known as Physicians, are licensed health ");
        System.out.println("professionals who maintain and restore human health through the ");
        System.out.println("practice of medicine. They examine patients, review their medical ");
        System.out.println("history, diagnose illnesses or injuries, administer treatment and ");
        System.out.println("counsel patients on their health and well being.");
        System.out.println(" ");
        System.out.println("--------------------------------------------------------------------------");
        
    
    }
       
}
