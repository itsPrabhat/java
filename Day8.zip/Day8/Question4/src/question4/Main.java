package question4;
public class Main {
    
    public static void main(String[] args){
        
        int i;
        Employee1[] emp1=new Employee1[3];
        Employee2[] emp2=new Employee2[3];
        Employee3[] emp3=new Employee3[3];
        
        for(i=0;i<3;i++){
        
            System.out.println("Employee1["+(i+1)+"]");
            emp1[i]=new Employee1();
            System.out.println(" ");
            System.out.println("Employee2["+(i+1)+"]");
            emp2[i]=new Employee2();
            System.out.println(" ");
            System.out.println("Employee3["+(i+1)+"]");
            emp3[i]=new Employee3();
            System.out.println(" ");
            System.out.println("=======================================================================");
        
        }
    
    
    }
    
}
