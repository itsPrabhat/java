package question4;
import java.util.Scanner;

public class Employee2 {
    
    private String name,designation;
    private int age, salary;
    
    Scanner sc=new Scanner(System.in);
    
    
    Employee2(){
    
        
        getDetails();
        System.out.println(" ");
        System.out.println("Entered details are:");
        displayDetails();
        System.out.println("---------------------------");
    
    }
    
    public void displayDetails(){
    
        System.out.println("Name: "+name);
        System.out.println("Age: "+age);
        System.out.println("Salary: "+salary);
        System.out.println("Designation: "+designation);

    }
    
    public void getDetails(){
    
        System.out.println("Enter name: ");
        name=sc.next();
        System.out.println("Enter age: ");
        age=sc.nextInt();
        System.out.println("Enter salary: ");
        salary=sc.nextInt();
        System.out.println("Enter designation: ");
        designation=sc.next();
    
    }
    
    
}
