package question3;

public class Main {

    public static void main(String[] args) {
        
        Object[] ob=new Object[3];
        
        int i;
        
        for(i=0;i<3;i++){
            
            System.out.println("Enter details of Object["+(i+1)+"]");
            
            ob[i]=new Object();
        
        
        }
        
        
        
    }
    
}
