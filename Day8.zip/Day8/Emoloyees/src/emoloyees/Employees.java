package emoloyees;

public class Employees {
    
    Employees(){
    
        Employee1 emp1=new Employee1();
        Employee2 emp2=new Employee2();
        Employee3 emp3=new Employee3();
    
    
    }
    
}
