package emoloyees;

public class Main {

    public static void main(String[] args) {
       
        Employees emps=new Employees();
        
    }
    
}
