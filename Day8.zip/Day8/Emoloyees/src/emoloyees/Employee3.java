package emoloyees;

import java.util.Scanner;

public class Employee3 {
    
    private String name,designation;
    private int age, salary;
    
    Scanner sc=new Scanner(System.in);
    
    
    Employee3(){
    
        System.out.println("Enter details of employ 3");
        getDetails();
        System.out.println("Details of employ 3 are:");
        displayDetails();
        System.out.println("---------------------------");
    
    }
    
    public void displayDetails(){
    
    System.out.println(name+" "+age+" "+salary+" "+designation);

    }
    
    public void getDetails(){
    
        System.out.println("Enter name: ");
        name=sc.next();
        System.out.println("Enter age: ");
        age=sc.nextInt();
        System.out.println("Enter salary: ");
        salary=sc.nextInt();
        System.out.println("Enter designation: ");
        designation=sc.next();
    
    }
    
    
}
