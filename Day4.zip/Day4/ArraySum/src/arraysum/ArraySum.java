package arraysum;
import java.util.Scanner;
public class ArraySum {

    public static void main(String[] args) {
       
        int sum=0;
        // declears an array
        int[] arr;
        // allocates memory to array
        arr = new int[5];
        
        Scanner sc=new Scanner(System.in);
        
        for(int i=0;i<5;i++){
            
            System.out.println("Enter element at index "+i);
            arr[i]=sc.nextInt();
            
        }
        
        for(int i=0;i<5;i++){
            
            sum+=arr[i];
            
        }
        
        System.out.println("Sum: "+sum);
        
    }
    
}
