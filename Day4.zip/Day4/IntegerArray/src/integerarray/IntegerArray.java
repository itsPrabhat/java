package integerarray;

public class IntegerArray {

    public static void main(String[] args) {
        
        //declears an array
        int[] arr;
        //allocating memory to array
        arr=new int[5];
        
        arr[0]=16;
        arr[1]=35;
        arr[2]=73;
        arr[3]=38;
        arr[4]=67;
        
        for(int i=0;i<5;i++){
        
            if(arr[i]%2==1){
            
                System.out.println(arr[i]+" at index "+i+" is odd");
                
            }
            
        }
         
    }
    
}
