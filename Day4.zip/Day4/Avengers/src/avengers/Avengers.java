package avengers;
import java.util.Scanner;
    
public class Avengers {
    
    public String name,power,weapon,planet;
    public int age;
    
    public void getDetails(){
        
        Scanner sc=new Scanner(System.in);
        
        System.out.println("Enter name of Avenger: ");
        name=sc.next();
        System.out.println("Enter Age of Avenger: ");
        age=sc.nextInt();
        System.out.println("Enter power of Avenger: ");
        power=sc.next();
        System.out.println("Enter weapon of Avenger: ");
        weapon=sc.next();
        System.out.println("Enter planet of Avenger: ");
        planet=sc.next();
    
    }
    
    public void displayDetails(){
        
        System.out.println("Name of Avenger: "+name);
        System.out.println("Age of Avenger: "+age);
        System.out.println("Power of Avenger: "+power);
        System.out.println("Weapon of Avenger: "+weapon);
        System.out.println("Planet of Avenger: "+planet);
    
    }
    
}
