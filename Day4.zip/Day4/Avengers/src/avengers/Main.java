
package avengers;

public class Main {
    

    public static void main(String[] args) {
        
        Avengers[] avengers=new Avengers[5];
        int n;
        for(int i=0;i<5;i++){
            n=i+1;
            System.out.println("Enter details of Avenger "+n);
            avengers[i]=new Avengers();
            avengers[i].getDetails();
        }
        
        for(int i=0;i<5;i++){
            n=i+1;
            System.out.println("Details of Avenger "+n);
            avengers[i].displayDetails();
        }
    }
    
}
